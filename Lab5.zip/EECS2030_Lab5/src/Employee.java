import java.util.Date;

public class Employee extends Person {
}
