package labTest1;
public class LockedStorageException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
