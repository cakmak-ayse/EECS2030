package labTest1;
/** The class implements an object that allows protecting the stored content via a password
 * @author Andriy
 * TODO complete the implementation of the class (constructors, methods...)
 */
public class LockedStorage {

	/** Creates an object with a specified password
	 * and an empty content (an  empty string)
	 * The object should be in an "unlocked" state
	 * @param password
	 */
	public LockedStorage(String password) {
	}

	/** Creates  an object with a specified password
	 * and the specified  content
	 * The object should be in an "unlocked" state
	 * @param password
	 * @param content
	 */
	public LockedStorage(String password, String content) {
	}
	
	/**Set the contents of the object to a new value
	 * @param content new content
	 * @return true if the operations is successful, else false
	 * or throw a LockedStorageException if the object is locked 
	 */
	public boolean setContent(String content){
		return false;
	}
	
	/**Get the contents of the object
	 * @return the contents of the object
	 * or throw a LockedStorageException if the object is locked
	 */
	public String getContent(){
		return null;
	}
	
	/**Changes the  password of the object
	 * @param password new password
	 * or throw a LockedStorageException if the object is locked
	 */
	public void setPassword(String password){
	}
	
	/** Locks the object
	 *  No effect if the object is already locked 
	 */
	public void lock(){
	}
	
	/**Unlocks the object, to enable accessing and updating the content
	 * @param password the password to unlock
	 * @return true if  the password was correct, false otherwise
	 */
	public boolean unlock(String password){
		return false;
	}
	
	/**Return the state of the object
	 * true - locked
	 * false - unlocked
	 * @return the object state
	 */
	public boolean isLocked(){
		return false;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * returns a string representation of the object
	 * "LOCKED" if the object is locked
	 * "Content:" followed by a new line character 
	 * and the actual content otherwise
	 */
	@Override
	public String toString(){
		return null;
	}
	
}
