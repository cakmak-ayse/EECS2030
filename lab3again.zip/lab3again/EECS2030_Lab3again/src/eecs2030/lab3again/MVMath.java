package eecs2030.lab3;

/**
 * A utility class containing some matrix/vector operations
 * @author Andriy
 * EECS 2030 Lab 3 SU2020
 */
public class MVMath {
	
	/**
	 * Multiplies a matrix by a vector
	 * @param m matrix
	 * @param v vector
	 * @return new vector object containing the result
	 */
	public static Vector3 multiply (Matrix3 m, Vector3 v){
		return null;
	}

	/**
	 * @param m1 matrix 1
	 * @param m2 matrix 2
	 * @return new matrix object containing the result
	 */
	public static Matrix3 multiply (Matrix3 m1, Matrix3 m2){
	    return null;
	}
	
	/**
	 * Computes a cross product of two vectors
	 * @param v1 vector 1
	 * @param v2 vector 2
	 * @return a new vector object containing the result
	 */
	public static Vector3 crossProduct (Vector3 v1, Vector3 v2){
		return null;
	}

	/**
	 * Computes a dot product of two vectors
	 * @param v1 vector 1
	 * @param v2 vector 2
	 * @return dot product (a scalar)
	 */
	public static double dotProduct (Vector3 v1, Vector3 v2){
		return 0.0;
	}

}
