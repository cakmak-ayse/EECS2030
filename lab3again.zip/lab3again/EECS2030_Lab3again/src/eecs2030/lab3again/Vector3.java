package eecs2030.lab3;

import java.util.Arrays;

/**
 * An immutable class implementing a 3D vector 
 * @author Andriy
 * EECS 2030 Lab 3 SU2020
 *
 */
public class Vector3 implements Comparable <Vector3>{

	/**
	 * Creates a 3D vector from an array
	 * @param v array containing 3 components of the desired vector 
	 */
	public Vector3(double[] v) {
	}

	/**
	 * Creates a 3D vector from 3 numeric scalar components
	 * @param x x coordinate
	 * @param y y coordinate
	 * @param z z coordinate
	 */
	public Vector3(double x, double y, double z) {
	}

	/**
	 * Clones an existing vector
	 * @param old an existing Vector3 object 
	 */
	public Vector3(Vector3 old) {
	}

	/**
	 * Returns a vector component at a specified index
	 * @param index the index of the vector component
	 * @return vector component as a scalar
	 */
	public double getElement (int index){
		return 0d;
	}

	/**
	 * Returns vector components as an array
	 * @return
	 */
	public double[] getElements (){
		return null;
	}

	@Override
	public int hashCode() {
		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		return true;
	}

	@Override
	public int compareTo(Vector3 o) {
		return 0;
	}
	
	
}
